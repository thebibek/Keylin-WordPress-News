<?php
if (!function_exists('bk_demo_config_options')) {
    function bk_demo_config_options(){
        $count = 0;
        $bk_theme_demos = array();
        for($count = 1; $count <= BK_DEMO_COUNT; $count++) {
            $bk_theme_demos['demo_'.$count] = array (
                 'class' => 'demo_'.$count,
                 'title' => 'Keylin (Main Demo)',
                 'img'   => BK_AD_PLUGIN_URL . 'demo_content/demo_'.$count.'/screenshot.png',
            );
            switch($count) {
                case(1):
                    $bk_theme_demos['demo_'.$count]['title'] = 'Keylin (Main Demo)';
                    break;
                case(2):
                    $bk_theme_demos['demo_'.$count]['title'] = 'Fashion';
                    break;
                case(3):
                    $bk_theme_demos['demo_'.$count]['title'] = 'Newspaper';
                    break;
                case(4):
                    $bk_theme_demos['demo_'.$count]['title'] = 'Art';
                    break;
                case(5):
                    $bk_theme_demos['demo_'.$count]['title'] = 'Minimal';
                    break;
                case(6):
                    $bk_theme_demos['demo_'.$count]['title'] = 'Food';
                    break;
                case(7):
                    $bk_theme_demos['demo_'.$count]['title'] = 'Travel';
                    break;
                case(8):
                    $bk_theme_demos['demo_'.$count]['title'] = 'Nature';
                    break;
                case(9):
                    $bk_theme_demos['demo_'.$count]['title'] = 'Street Art';
                    break;
                case(10):
                    $bk_theme_demos['demo_'.$count]['title'] = 'Boxing';
                    break;
                case(11):
                    $bk_theme_demos['demo_'.$count]['title'] = 'Men Magazine';
                    break;
            }
        }
            
        $import_source = array();
        for($count = 1; $count <= BK_DEMO_COUNT; $count++) {
            $import_source['demo_'.$count] = array (
                'content'       => BK_AD_PLUGIN_DIR . 'demo_content/content_files/content.xml',
                'widgets'       => BK_AD_PLUGIN_DIR . 'demo_content/content_files/widgets.wie',
                'theme_options' => BK_AD_PLUGIN_DIR . 'demo_content/demo_'.$count.'/theme_options.json',
            );
        }  
        wp_localize_script( 'bkadscript', 'import_source', $import_source );
        return $bk_theme_demos;        
    }        
}    