<?php
/*
Plugin Name: Keylin Extension
Plugin URI: 
Description: Keylin extension (more functional, widgets, etc.)
Author: bkninja
Version: 1.0
Author URI: http://bk-ninja.com
*/
if (!defined('KEYLIN_FUNCTIONS_PLUGIN_DIR')) {
    define('KEYLIN_FUNCTIONS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}
include(KEYLIN_FUNCTIONS_PLUGIN_DIR."/widgets/widget-about.php");
include(KEYLIN_FUNCTIONS_PLUGIN_DIR."/widgets/widget-posts-list.php");
include(KEYLIN_FUNCTIONS_PLUGIN_DIR."/widgets/widget-most-commented.php");
include(KEYLIN_FUNCTIONS_PLUGIN_DIR."/widgets/widget-review-list.php");
include(KEYLIN_FUNCTIONS_PLUGIN_DIR."/widgets/widget-social-counters.php");
include(KEYLIN_FUNCTIONS_PLUGIN_DIR."/widgets/widget-subscribe.php");
include(KEYLIN_FUNCTIONS_PLUGIN_DIR."/widgets/widget-twitter.php");
include(KEYLIN_FUNCTIONS_PLUGIN_DIR."/widgets/widget-category-tiles.php");

function check_activate_plugin() {
    if ( is_plugin_active( 'redux-framework/redux-framework.php' )) {
        deactivate_plugins('redux-framework/redux-framework.php');
    }
    if ( is_plugin_active( 'mb-term-meta/mb-term-meta.php' )) {
        deactivate_plugins('mb-term-meta/mb-term-meta.php');
    }
    if ( is_plugin_active( 'meta-box-conditional-logic/meta-box-conditional-logic.php' )) {
        deactivate_plugins('meta-box-conditional-logic/meta-box-conditional-logic.php');
    }
    if ( is_plugin_active( 'atbs-sidebar-generator/atbs-sidebar-generator.php' )) {
        deactivate_plugins('atbs-sidebar-generator/atbs-sidebar-generator.php');
    }
}
add_action( 'admin_init', 'check_activate_plugin' );

if ( !class_exists( 'ReduxFramework' ) && file_exists( plugin_dir_path( __FILE__ ) . '/redux-framework/redux-core/framework.php' ) ) {
    require_once( plugin_dir_path( __FILE__ ) . '/redux-framework/redux-core/framework.php' );
}

if ( file_exists( plugin_dir_path( __FILE__ ) . '/mb-term-meta/mb-term-meta.php' ) ) {
    require_once( plugin_dir_path( __FILE__ ) . '/mb-term-meta/mb-term-meta.php' );
}

if ( file_exists( plugin_dir_path( __FILE__ ) . '/meta-box-conditional-logic/meta-box-conditional-logic.php' ) ) {
    require_once( plugin_dir_path( __FILE__ ) . '/meta-box-conditional-logic/meta-box-conditional-logic.php' );
}

if ( file_exists( plugin_dir_path( __FILE__ ) . '/atbs-sidebar-generator/atbs-sidebar-generator.php' ) ) {
    require_once( plugin_dir_path( __FILE__ ) . '/atbs-sidebar-generator/atbs-sidebar-generator.php' );
}

if ( ! function_exists( 'atbs_contact_data' ) ) {  
    function atbs_contact_data($contactmethods) {
    
        unset($contactmethods['aim']);
        unset($contactmethods['yim']);
        unset($contactmethods['jabber']);
        $contactmethods['publicemail'] = 'Public Email';
        $contactmethods['twitter'] = 'Twitter URL';
        $contactmethods['facebook'] = 'Facebook URL';
        $contactmethods['youtube'] = 'Youtube URL';
         
        return $contactmethods;
    }
}
add_filter('user_contactmethods', 'atbs_contact_data');

/**-------------------------------------------------------------------------------------------------------------------------
 * remove redux sample config & notice
 */
if ( ! function_exists( 'atbs_redux_remove_notice' ) ) {
	function atbs_redux_remove_notice() {
		if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
			remove_filter( 'plugin_row_meta', array( ReduxFrameworkPlugin::instance(), 'plugin_metalinks' ), null, 2 );
			remove_action( 'admin_notices', array( ReduxFrameworkPlugin::get_instance(), 'admin_notices' ) );
		}
	}
	add_action( 'redux/loaded', 'atbs_redux_remove_notice' );
}
if ( ! function_exists( 'atbs_set__cookie' ) ) {
    function atbs_set__cookie(){
        if (class_exists('atbs_core')) {
            $atbs_option = atbs_core::bk_get_global_var('atbs_option');
            $cookietime = $atbs_option['bk-post-view--cache-time'];
            //echo (preg_replace('/[^A-Za-z0-9]/', '', $_SERVER["REQUEST_URI"]));
            $bk_uri = explode('/', $_SERVER["REQUEST_URI"]);
            $bkcookied = 0;
            if($bk_uri[count($bk_uri) - 1] !== '') {
                $cookie_name = preg_replace('/[^A-Za-z0-9]/', '', $bk_uri[count($bk_uri) - 1]);
            }else {
                $cookie_name = preg_replace('/[^A-Za-z0-9]/', '', $bk_uri[count($bk_uri) - 2]);
            }
            if(!isset($_COOKIE[$cookie_name])) {
                setcookie($cookie_name, '1', time() + $cookietime);  /* expire in 1 hour */
                $bkcookied = 1;
            }else {
                $bkcookied = 0;
            }
            return $bkcookied;
        }
    }
}
/**-------------------------------------------------------------------------------------------------------------------------
 * atbs_extension_single_entry_interaction
 */
if ( ! function_exists( 'atbs_extension_single_entry_interaction' ) ) {
	function atbs_extension_single_entry_interaction($postID) {
	   ?>
        <div class="entry-interaction entry-interaction--horizontal">
        	<div class="entry-interaction__left">
        		<div class="post-sharing post-sharing--simple">
        			<ul>
        				<?php echo ATBS_Single::bk_entry_interaction_share($postID);?>
        			</ul>
        		</div>
        	</div>
        
        	<div class="entry-interaction__right">
        		<?php echo ATBS_Single::bk_entry_interaction_comments($postID);?>
        	</div>
        </div>
    <?php
    }
}
/**-------------------------------------------------------------------------------------------------------------------------
 * atbs_extension_single_entry_interaction__sticky_share_box
 */
if ( ! function_exists( 'atbs_extension_single_entry_interaction__sticky_share_box' ) ) {
    function atbs_extension_single_entry_interaction__sticky_share_box($postID, $class= '') {
        echo ATBS_Single::bk_entry_interaction_share_svg($postID, $class);
    }
    
}
/**-------------------------------------------------------------------------------------------------------------------------
 * atbs_extension_single_entry_share_box
 */
if ( ! function_exists( 'atbs_extension_single_entry_share_box' ) ) {
    function atbs_extension_single_entry_share_box($postID, $class= '') {
       ?>
        <div class="single-contentshare- <?php echo esc_html($class);?> social-share-single-mobile">
            <ul class="social-share text-center">
                
                    <?php echo ATBS_Single::bk_entry_interaction_share($postID);?>
                
            </ul>
        </div>
    <?php
    }
}

/**-------------------------------------------------------------------------------------------------------------------------
 * atbs_extension_single_entry_share_box_keylin
 */
if ( ! function_exists( 'atbs_extension_single_entry_share_box_keylin' ) ) {
    function atbs_extension_single_entry_share_box_keylin($postID, $class= '') {
       ?>
                
        <div class="single-social-share <?php echo esc_html($class);?>">
            <div class="social-share">
                <ul class="social-list social-list--sm list-horizontal list-space-xxs">
                    <?php echo ATBS_Single::bk_entry_interaction_share($postID);?>
                </ul>
            </div>
        </div>
        
    <?php
    }
}
?>