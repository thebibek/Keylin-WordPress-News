<?php
/**
 * Silence is golden.
 *
 * @package Redux Framework
 */

// Shim file for odd theme integrations.

echo null;
